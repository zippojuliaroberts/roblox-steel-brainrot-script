# roblox-steel-brainrot-script
This script allows you to steal other players' gear through walls. 
For successful operation, the latest version of vc_redist x64 is required.
